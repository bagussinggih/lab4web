<footer>
        <p>&copy; 2024 - Teknik Informatika - Universitas Pelita Bangsa</p>
    </footer>
</div>
</body>
</html>