<?php require('header.php'); ?> 

<div class="content">
<h2>Ini Halaman Home</h2> 
   <p>Ini adalah bagian content dari halaman.</p> 
</div> 
  
<?php require('footer.php'); ?>